public interface UserInterFace<t> {

    void addUser();

    void showAllUser();

    void userCard();


}


